<?php
namespace App\Class;
class Calcul {


	public function add(int $a, int  $b)
	{
		$this->a =$a;
		$this->b =$b;
		$add = $a+$b;
		return $add;
	}

	public function sous(int $a, int  $b)
	{
		$this->a =$a;
		$this->b =$b;
		$sous = $a-$b;
		return $sous;
	}

	public function multi(int $a, int $b)
	{
		$this->a =$a;
		$this->b =$b;
		$multi = $a*$b;
		return $multi;
	}

	public function div(int $a, int $b)
	{
		$this->a =$a;
		$this->b =$b;
		$div = $a/$b;
		return $div;
	}

}