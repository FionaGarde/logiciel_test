<?php

namespace Mock;

class MathMock
{
    public function __construct() {
    }

    public function pi() {
  		return 3;
  	}

}
