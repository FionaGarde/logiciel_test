<?php
namespace App;

class User
{
    private $firstname;
    private $lastname;
    private $email;
    private $age;

    public function __construct() {
    }

    public function firstname(string $firstname) {
  		return $firstname;
  	}

    public function lastname(string $lastname) {
  		return $lastname;
  	}

    public function email(string $email) {
  		return $email;
  	}

    public function age(int $age) {
        if ($age > 13 || $age == 13) 
            return $age;
        
  	}

}
